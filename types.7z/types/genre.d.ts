type Genre = {
    id: number;
    created_at: string /* Date */ | null;
    updated_at: string /* Date */ | null;
    title: string;
};
