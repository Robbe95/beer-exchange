type Group = {
    id: number;
    created_at: string /* Date */ | null;
    updated_at: string /* Date */ | null;
    title: string;
    image: string | null;
    information: string | null;
    private_information: string | null;
    votes_locked: boolean;
    start_time: string /* Date */;
    host_id: number;
    location_id: number | null;
    games_with_votes?: any;
    host: User,
    players: Array<User>,
    applicants: Array<User>,
    rejected: Array<User>,
    games: Array<Game>
    location: Location
};
